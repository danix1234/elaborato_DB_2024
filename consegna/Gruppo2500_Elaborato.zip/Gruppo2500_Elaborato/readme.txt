Applicazione per la gestione di una compagnia aerea


Per eseguire l'applicazione:
- aprire mysql workbench, ed eseguire i file 'create_tables.sql' e 'initialize_tables.sql' presenti nella cartella 'mysql'
- creare un file nella home directory e chiamarlo '.compagnia_aerea'
- nel file appena creato, inserire nella prima riga l'user di mysql-workbench, e nella seconda riga la password per myqsl-workbench
- eseguire l'applicazione con './gradlew run' (unix), o con '.\gradlew.bat run' (Windows)

Ci si riferisca alla relazione per spiegazioni relative all'utilizzo dell'interfaccia grafica!
